/*
 1101_AC & DC DRIVERS
 proj.3 TIMER_interrupt
 input_NONE
 output_GPIO0_pin40
 */

//
// Included Files
//
#include "F28x_Project.h"

    // �X���\��}��
    // ��X�}�� : GPIO0:�{�O(�X���\��Ұʮɰ{�{�A�Ȱ��ɺ���)
    // ��J�}�� : GPIO1:�}�l/�Ȱ���     GPIO2:�k�s��    GPIO3:����p����

    int sec = 0;      // �����X������
    int min = 0;      // �����X������
    int round = 0;    // �������
    int sec_record = 0;  // �����Ӱ����
    int min_record = 0;  // �����Ӱ����
    int i = 0;        // �p�ɥ�

//
// Function Prototypes
//
void Gpio_setup(void);
void timer_setup(void);
__interrupt void cpu_timer0_isr(void);

void main(void)
{

//
// Step 1. Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the F2837xD_SysCtrl.c file.
//
   InitSysCtrl();

//
// Step 2. Initialize GPIO:
// This example function is found in the F2837xD_Gpio.c file and
// illustrates how to set the GPIO to it's default state.
//
// InitGpio();  // Skipped for this example

//
// Step 3. Clear all __interrupts and initialize PIE vector table:
//
   DINT;

//
// Initialize the PIE control registers to their default state.
// The default state is all PIE __interrupts disabled and flags
// are cleared.
// This function is found in the F2837xD_PieCtrl.c file.
//
   InitPieCtrl();

//
// Disable CPU __interrupts and clear all CPU __interrupt flags:
//
   IER = 0x0000;
   IFR = 0x0000;

//
// Initialize the PIE vector table with pointers to the shell Interrupt
// Service Routines (ISR).
// This will populate the entire table, even if the __interrupt
// is not used in this example.  This is useful for debug purposes.
// The shell ISR routines are found in F2837xD_DefaultIsr.c.
// This function is found in F2837xD_PieVect.c.
//
   InitPieVectTable();

//
// Interrupts that are used in this example are re-mapped to
// ISR functions found within this file.
//

   EALLOW;  // This is needed to write to EALLOW protected registers
   PieVectTable.TIMER0_INT = &cpu_timer0_isr;
   //PieVectTable.ECAP1_INT = &ecap1_isr;
   EDIS;    // This is needed to disable write to EALLOW protected registers

/*
// Step 4. Initialize the Device Peripheral. This function can be
//         found in F2837xD_CpuTimers.c
//
   InitCpuTimers();   // For this example, only initialize the Cpu Timers
*/

   timer_setup();

//
// Step 5. User specific code, enable __interrupts:
// Configure GPIO0 as a GPIO output pin
//
   Gpio_setup();


//
// Enable CPU INT1 which is connected to CPU-Timer 0:
//
   IER |= M_INT1;

//
// Enable TINT0 in the PIE: Group 1 __interrupt 7
//
   PieCtrlRegs.PIEIER1.bit.INTx7 = 1;

//
// Enable global Interrupts and higher priority real-time debug events:
//
   EINT;   // Enable Global __interrupt INTM
   ERTM;   // Enable Global realtime __interrupt DBGM

//
// Step 6. IDLE loop. Just sit and loop forever (optional):
//
   while(true)
   {
       if (GpioDataRegs.GPADAT.bit.GPIO1 == 1)    // �X���p�ɶ}�l
           CpuTimer0Regs.TCR.bit.TSS = 0;
       else if (GpioDataRegs.GPADAT.bit.GPIO2 == 1)    // �X���Ȱ�
       {
           CpuTimer0Regs.TCR.bit.TSS = 1;
           GpioDataRegs.GPADAT.bit.GPIO0 = 0;
       }

       if (GpioDataRegs.GPADAT.bit.GPIO2 == 1 && GpioDataRegs.GPADAT.bit.GPIO3 == 1)  // �X���k�s
       {
           sec = 0;
           min = 0;
           round = 0;
           sec_record = 0;
           min_record = 0;
           CpuTimer0Regs.TCR.bit.TSS = 1;
           GpioDataRegs.GPADAT.bit.GPIO0 = 0;
       }

   }
}

//
// cpu_timer0_isr - CPU Timer0 ISR that toggles GPIO32 once per 500ms
//

void Gpio_setup(void)
{
    EALLOW;

    GpioCtrlRegs.GPAPUD.bit.GPIO1 = 0;   // Enable pullup on GPIO1
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 0;  // GPIO1 = GPIO1
    GpioCtrlRegs.GPADIR.bit.GPIO1 = 0;  // GPIO1 = intput

    GpioCtrlRegs.GPAPUD.bit.GPIO2 = 0;   // Enable pullup on GPIO2
    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 0;  // GPIO2 = GPIO2
    GpioCtrlRegs.GPADIR.bit.GPIO2 = 0;  // GPIO2 = intput

    GpioCtrlRegs.GPAPUD.bit.GPIO3 = 0;   // Enable pullup on GPIO3
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 0;  // GPIO3 = GPIO3
    GpioCtrlRegs.GPADIR.bit.GPIO3 = 0;  // GPIO3 = intput

    GpioCtrlRegs.GPAPUD.bit.GPIO0 = 0;  // Enable pullup on GPIO0
    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 0;  // GPIO0 = GPIO0
    GpioCtrlRegs.GPADIR.bit.GPIO0 = 1;  // GPIO0 = output

    EDIS;
}

void timer_setup(void)
{
    //Set the timer period to 0.2 seconds. Counter decrements PRD+1 times each period
    CpuTimer0Regs.PRD.all = 0.2*100000000-1;//CPU work at 100MHz, so count 100000000 will be 1 second.
    // Set pre-scale counter to divide by 1 (SYSCLKOUT):
    CpuTimer0Regs.TPR.all = 0;
    CpuTimer0Regs.TPRH.all = 0;
    // Initialize timer control register:
    CpuTimer0Regs.TCR.bit.TSS = 1; // 1 = Stop timer, 0 = Start/Restart timer
    CpuTimer0Regs.TCR.bit.TRB = 1; // 1 = reload timer
    CpuTimer0Regs.TCR.bit.SOFT = 0;
    CpuTimer0Regs.TCR.bit.FREE = 0;
    CpuTimer0Regs.TCR.bit.TIE = 1; // 0 = Disable/ 1 = Enable Timer Interrupt
}

__interrupt void cpu_timer0_isr(void)
{
   GpioDataRegs.GPATOGGLE.bit.GPIO0 = 1;
   i++;
   if (i==5)
   {
       sec++;
       if (sec==60)
       {
           sec = 0;
           min++;
       }
       i=0;
   }

   if (GpioDataRegs.GPADAT.bit.GPIO3 == 1)   // ����p��
   {
       round++;
       sec_record = sec;
       min_record = min;
   }

   //
   // Acknowledge this __interrupt to receive more __interrupts from group 1
   //
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

//
// End of file
//
