#include "F28x_Project.h"
#include "math.h"

void ConfigureADC(void);
void ConfigureSOC(void);

void InitEPwm(void);
void SetupADCEpwm(void);

void InitECapture(void);
void timer_setup(void);
void Gpio_setup(void);
void Section(void);
void CCW(void);
void CW(void);
void Break(void);

interrupt void adca1_isr(void);
__interrupt void ecap1_isr(void);
__interrupt void cpu_timer0_isr(void);

int a=0;

int dt=0;
int mode=0;
int hu,hv,hw;
int section;
const int ccw[7]={0,2,4,3,6,1,5};
const int cw[7]={0,5,1,6,3,4,2};
int table[8][6]={{5000,5000,5000,5000,5000,5000}, //null
                 {0,5000,5000,0,5000,5000}, //1
                 {0,5000,5000,5000,5000,0}, //2
                 {5000,5000,0,5000,5000,0}, //3
                 {5000,0,0,5000,5000,5000}, //4
                 {5000,0,5000,5000,0,5000}, //5
                 {5000,5000,5000,0,0,5000}, //6
                 {5000,0,5000,0,5000,0}}; //break
// for velocity estimation
unsigned int t=0;
unsigned int t1,t2,delta_t;
int s,n;  // s:�O���e��section  n:���V����
float rpm;
int rpm_avg;
Uint16 rpmResults[10];
Uint16 rpmIndex = 0;
//
// Defines
//
#define RESULTS_BUFFER_SIZE 20 //data pool size, 20 data
#define PI 3.14159
//
// Globals
//
Uint16 AdcaResults[RESULTS_BUFFER_SIZE]; //ADC data pool
Uint16 resultsIndex = 0;    //data input index
Uint16 DutyTable[101];  //output table for PWM
Uint16 set_period;  //output data, work with PWM period TimeBase
const Uint16 adcres = 4095;     //2^12-1
const Uint16 TimeBase = 5000;  //period=0.1ms
Uint16 tableIndex = 0;
Uint16 sumindex = 0;

/**
 * main.c
 */
void main(void)
{
//
// Step 1. Initialize System Control:
// PLL, WatchDog, enable Peripheral Clocks
// This example function is found in the F2837xD_SysCtrl.c file.
//
    InitSysCtrl();

// Step 2. Initialize GPIO pins for ePWM2
    InitEPwm2Gpio();
    InitEPwm3Gpio();
    InitEPwm4Gpio();
    CpuSysRegs.PCLKCR2.bit.EPWM1 = 1;  //enable epwm1 clock
    CpuSysRegs.PCLKCR2.bit.EPWM2 = 1;  //enable epwm2 clock
    CpuSysRegs.PCLKCR2.bit.EPWM3 = 1;
    CpuSysRegs.PCLKCR2.bit.EPWM4 = 1;

//
// Configure the ADC and power it up
//
    ConfigureADC();
//
// Configure the ePWM SOC
//
    ConfigureSOC();
//
// Setup the ADC for ePWM triggered conversions
//
    SetupADCEpwm();
//
// Step 3. Clear all interrupts and initialize PIE vector table:
// Disable CPU interrupts
//
    DINT;

//
// Initialize the PIE control registers to their default state.
// The default state is all PIE interrupts disabled and flags
// are cleared.
// This function is found in the F2837xD_PieCtrl.c file.
//
    InitPieCtrl();

//
// Disable CPU interrupts and clear all CPU interrupt flags:
//
    IER = 0x0000;
    IFR = 0x0000;

//
// Initialize the PIE vector table with pointers to the shell Interrupt
// Service Routines (ISR).
// This will populate the entire table, even if the interrupt
// is not used in this example.  This is useful for debug purposes.
// The shell ISR routines are found in F2837xD_DefaultIsr.c.
// This function is found in F2837xD_PieVect.c.
//
    InitPieVectTable();

//
// Map ISR functions
//

    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.TIMER0_INT = &cpu_timer0_isr;
    EDIS;

    EALLOW;
    PieVectTable.ADCA1_INT = &adca1_isr; //function for ADCA interrupt 1
    EDIS;

    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.ECAP1_INT = &ecap1_isr;
    EDIS;

    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0; // Closed synchronize between base clock and all enabled ePWM modules
    EDIS;


//
// InitEPwm2 - Initialize EPWM2 configuration
//
    InitEPwm();

    InitECapture();
    timer_setup();
    Gpio_setup();
//
// sync ePWM
//
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;

//
// Enable global Interrupts and higher priority real-time debug events:
//
    IER |= M_INT1; //Enable group 1 interrupts
    IER |= M_INT4;
//
// enable PIE interrupt
//
    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;
    PieCtrlRegs.PIEIER4.bit.INTx1 = 1;

    EINT;   // Enable Global interrupt INTM
    ERTM;   // Enable Global realtime interrupt DBGM

    CpuTimer0Regs.TCR.bit.TSS = 0;

    Uint16 i; //for index, only used in Main
    for (i = 0; i <= 1000; i++)
    {
        DutyTable[i] = TimeBase/1000*i;
    }
    mode = 0;
    n = 0;
    t = 0;
    delta_t = 0;
    rpm = 0;
    rpm_avg = 0;

    while (1)
    {
        a = ccw[section];
        table[1][0] = dt; table[1][3] = dt;
        table[2][0] = dt; table[2][5] = dt;
        table[3][2] = dt; table[3][5] = dt;
        table[4][1] = dt; table[4][2] = dt;
        table[5][1] = dt; table[5][4] = dt;
        table[6][3] = dt; table[6][4] = dt;

        if (mode == 0)  //ccw
        {
            Section();
            if (s != section)
                n++;
            CCW();
            s = section;
        }
        else if (mode == 1)  //cw
        {
            Section();
            if (s != section)
                n++;
            CW();
            s = section;
        }

    }

}

__interrupt void ecap1_isr(void)
{
    mode = 1 - mode ;
    Break();
    n = 0;

    ECap1Regs.ECCLR.bit.CEVT1 = 1;
    ECap1Regs.ECCLR.bit.INT = 1;
    ECap1Regs.ECCTL2.bit.REARM = 1;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;
}

__interrupt void cpu_timer0_isr(void)
{
   GpioDataRegs.GPATOGGLE.bit.GPIO0 = 1;
   t++;

   // velocity estimation
           if (n == 2)
               t1 = t;
           else if (n >= 14)
           {
               t2 = t;
               delta_t = t2-t1;
               n = 2;
               rpm = 60 / (delta_t*0.000001);
               rpmResults[rpmIndex++] = rpm;
               t = 0;
           }
           if (10 <= rpmIndex)
           {
               float rpm_sum = 0; //set 0, also check format
               Uint16 j;
               for (j = 0; j < 10; j++)
               {
                   rpm_sum += rpmResults[j]; //sum the result, can work as filtering
               }
               rpm_avg = rpm_sum/10.0;
               rpmIndex = 0;
           }
   //
   // Acknowledge this __interrupt to receive more __interrupts from group 1
   //
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
//
// adca1_isr - Read ADC Buffer in ISR
//
interrupt void adca1_isr(void)
{
    int e = 40;
    //
    AdcaResults[resultsIndex++] = AdcaResultRegs.ADCRESULT0; //catch the ADC results
    //
    if (RESULTS_BUFFER_SIZE <= resultsIndex)    //when data full enough
    {
        Uint32 sum = 0; //set 0, also check format

        for (sumindex = 0; sumindex < RESULTS_BUFFER_SIZE; sumindex++)
        {                                  //
            sum += AdcaResults[sumindex]; //sum the result, can work as filtering
        }                                     //
        tableIndex = (sum * 1000 / adcres / RESULTS_BUFFER_SIZE-e) * 1000 / (1000-e);

        dt = TimeBase - DutyTable[tableIndex];

       resultsIndex = 0;
    }

    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

void Section(void)
{
    hu=GpioDataRegs.GPADAT.bit.GPIO8;
    hv=GpioDataRegs.GPADAT.bit.GPIO9;
    hw=GpioDataRegs.GPADAT.bit.GPIO10;
    section=hu+hv*2+hw*4;
}

void CCW(void)
{
    EPwm2Regs.CMPA.bit.CMPA = table[ccw[section]][0];
    EPwm2Regs.CMPB.bit.CMPB = table[ccw[section]][1];
    EPwm3Regs.CMPA.bit.CMPA = table[ccw[section]][2];
    EPwm3Regs.CMPB.bit.CMPB = table[ccw[section]][3];
    EPwm4Regs.CMPA.bit.CMPA = table[ccw[section]][4];
    EPwm4Regs.CMPB.bit.CMPB = table[ccw[section]][5];
}

void CW(void)
{
    EPwm2Regs.CMPA.bit.CMPA = table[cw[section]][0];
    EPwm2Regs.CMPB.bit.CMPB = table[cw[section]][1];
    EPwm3Regs.CMPA.bit.CMPA = table[cw[section]][2];
    EPwm3Regs.CMPB.bit.CMPB = table[cw[section]][3];
    EPwm4Regs.CMPA.bit.CMPA = table[cw[section]][4];
    EPwm4Regs.CMPB.bit.CMPB = table[cw[section]][5];
}

void Break(void)
{
    EPwm2Regs.CMPA.bit.CMPA = table[0][0];
    EPwm2Regs.CMPB.bit.CMPB = table[0][1];
    EPwm3Regs.CMPA.bit.CMPA = table[0][2];
    EPwm3Regs.CMPB.bit.CMPB = table[0][3];
    EPwm4Regs.CMPA.bit.CMPA = table[0][4];
    EPwm4Regs.CMPB.bit.CMPB = table[0][5];
    DELAY_US(500000);
    EPwm2Regs.CMPA.bit.CMPA = table[7][0];
    EPwm2Regs.CMPB.bit.CMPB = table[7][1];
    EPwm3Regs.CMPA.bit.CMPA = table[7][2];
    EPwm3Regs.CMPB.bit.CMPB = table[7][3];
    EPwm4Regs.CMPA.bit.CMPA = table[7][4];
    EPwm4Regs.CMPB.bit.CMPB = table[7][5];
    DELAY_US(500000);
}

void ConfigureADC(void)
{
    EALLOW;

    //
    //write configurations
    //
    AdcaRegs.ADCCTL2.bit.PRESCALE = 6; //set ADCCLK divider to /4
    AdcSetMode(ADC_ADCA, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);

    //
    //Set pulse positions to late
    //
    AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    //
    //power up the ADC
    //
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;

    //
    //delay for 1ms to allow ADC time to power up
    //
    DELAY_US(10000); //This delay can also be used for kind of low inefficient debounce

    EDIS;
}
void InitECapture()
{
    EALLOW;
    InputXbarRegs.INPUT7SELECT = 14;         // Set eCAP1 source to GPIO14
    EDIS;
    ECap1Regs.ECEINT.all = 0x0000;          // Disable all capture __interrupts
    ECap1Regs.ECCLR.all = 0xFFFF;           // Clear all CAP __interrupt flags
    ECap1Regs.ECCTL1.bit.CAPLDEN = 0;       // Disable CAP1-CAP4 register loads
    ECap1Regs.ECCTL2.bit.TSCTRSTOP = 0;     // Make sure the counter is stopped

    //
    // Configure peripheral registers
    //
    ECap1Regs.ECCTL2.bit.CONT_ONESHT = 1;   // One-shot
    ECap1Regs.ECCTL1.bit.PRESCALE = 0;
    ECap1Regs.ECCTL2.bit.STOP_WRAP = 0;     // Stop at 1 events
    ECap1Regs.ECCTL1.bit.CAP1POL = 0;       // Rising edge

    ECap1Regs.ECCTL2.bit.TSCTRSTOP = 1;     // Start Counter
    ECap1Regs.ECCTL2.bit.REARM = 1;         // arm one-shot
    ECap1Regs.ECCTL1.bit.CAPLDEN = 1;       // Enable capture units
    ECap1Regs.ECEINT.bit.CEVT1 = 1;         // 1 events = __interrupt
}

void timer_setup(void)
{
    //Set the timer period to 0.01 seconds. Counter decrements PRD+1 times each period
    CpuTimer0Regs.PRD.all = 0.000001*100000000-1;//CPU work at 100MHz, so count 100000000 will be 1 second.
    // Set pre-scale counter to divide by 1 (SYSCLKOUT):
    CpuTimer0Regs.TPR.all = 0;
    CpuTimer0Regs.TPRH.all = 0;
    // Initialize timer control register:
    CpuTimer0Regs.TCR.bit.TSS = 1; // 1 = Stop timer, 0 = Start/Restart timer
    CpuTimer0Regs.TCR.bit.TRB = 1; // 1 = reload timer
    CpuTimer0Regs.TCR.bit.SOFT = 0;
    CpuTimer0Regs.TCR.bit.FREE = 0;
    CpuTimer0Regs.TCR.bit.TIE = 1; // 0 = Disable/ 1 = Enable Timer Interrupt
}

void Gpio_setup(void)
{
    EALLOW;

    GpioCtrlRegs.GPAPUD.bit.GPIO8 = 0;       // S1, connect TECO56 yellow signal cable to PIN80
    GpioCtrlRegs.GPAGMUX1.bit.GPIO8 = 0;     // Select input/output(GPIO) mode
    GpioCtrlRegs.GPAQSEL1.bit.GPIO8 = 0;     // Synchronous with SYSCLK
    GpioCtrlRegs.GPADIR.bit.GPIO8 = 0;       // Select input mode

    GpioCtrlRegs.GPAPUD.bit.GPIO9 = 0;       // S2, connect TECO56 ????? signal cable to PIN79
    GpioCtrlRegs.GPAGMUX1.bit.GPIO9 = 0;
    GpioCtrlRegs.GPAQSEL1.bit.GPIO9 = 0;
    GpioCtrlRegs.GPADIR.bit.GPIO9 = 0;

    GpioCtrlRegs.GPAPUD.bit.GPIO10 = 0;       // S3, connect TECO56 ???? signal cable to PIN78
    GpioCtrlRegs.GPAGMUX1.bit.GPIO10 = 0;
    GpioCtrlRegs.GPAQSEL1.bit.GPIO10 = 0;
    GpioCtrlRegs.GPADIR.bit.GPIO10 = 0;

    GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;   // Enable pullup on GPIO1
    GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 0;  // GPIO1 = GPIO1
    GpioCtrlRegs.GPADIR.bit.GPIO14 = 0;  // GPIO1 = intput

    GpioCtrlRegs.GPAPUD.bit.GPIO11 = 0;  // Enable pullup on GPIO0
    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 0;  // GPIO0 = GPIO0
    GpioCtrlRegs.GPADIR.bit.GPIO11 = 1;  // GPIO0 = output

    GpioDataRegs.GPADAT.bit.GPIO11 = 1;  // GPIO0 output low

    EDIS;
}
//
// SetupADCEpwm - Setup ADC EPWM acquisition window
//
void SetupADCEpwm(void)
{

    //
    //Select the channels to convert and end of conversion flag
    //
    EALLOW;
    AdcaRegs.ADCSOC0CTL.bit.CHSEL = 0;  //SOC0 will convert pin A0
    AdcaRegs.ADCSOC0CTL.bit.ACQPS = 99; //sample window is 100 SYSCLK cycles
    AdcaRegs.ADCSOC0CTL.bit.TRIGSEL = 5; //trigger on ePWM1 SOCA/C
/*
    AdcaRegs.ADCSOC1CTL.bit.CHSEL = 2;  //SOC0 will convert pin A0
    AdcaRegs.ADCSOC1CTL.bit.ACQPS = 99; //sample window is 100 SYSCLK cycles
    AdcaRegs.ADCSOC1CTL.bit.TRIGSEL = 5; //trigger on ePWM1 SOCA/C
*/
    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = 0; //0-> EOC0 is trigger for ADCINT1, will set INT1 flag

    AdcaRegs.ADCINTSEL1N2.bit.INT1E = 1;   //enable INT1 flag
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //make sure INT1 flag is cleared
    EDIS;
}

//
// ConfigureEPWM - Configure EPWM SOC and compare values
//
void ConfigureSOC(void)                                  ///only used for SOC!!!
{
    EALLOW;
    // Assumes ePWM clock is already enabled
    EPwm1Regs.ETSEL.bit.SOCAEN = 1;    // Enable SOC on A group
    EPwm1Regs.ETSEL.bit.SOCASEL = 2;   // Select SOC on period
    EPwm1Regs.ETPS.bit.SOCAPRD = 1;       // Generate pulse on 1st event
    EPwm1Regs.TBPRD = TimeBase * 0.05;    // Set period to TimeBase/20
    EPwm1Regs.TBCTL.bit.CTRMODE = 0;      // up count mode
    EDIS;
}

void InitEPwm()                                                 ///used for LED
{
    EPwm2Regs.TBPRD = TimeBase;                   // Set timer period
    EPwm2Regs.TBPHS.bit.TBPHS = 0x0000;           // Phase is 0
    EPwm2Regs.TBCTR = 0x0000;                     // Clear counter

    EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP; // Count UPDOWN
    EPwm2Regs.TBCTL.bit.PHSEN = TB_DISABLE;        // Disable phase loading
    EPwm2Regs.TBCTL.bit.HSPCLKDIV = 1;       // Clock ratio to SYSCLKOUT
    EPwm2Regs.TBCTL.bit.CLKDIV = 1;

    EPwm2Regs.CMPA.bit.CMPA = TimeBase;
    EPwm2Regs.CMPB.bit.CMPB = TimeBase;//CMPB

    EPwm2Regs.AQCTLA.bit.CAU = AQ_SET;            // Set PWM2A on Zero
    EPwm2Regs.AQCTLA.bit.PRD = AQ_CLEAR;//��

    EPwm2Regs.AQCTLB.bit.CBU = AQ_SET;            // Set PWM2B on Zero
    EPwm2Regs.AQCTLB.bit.ZRO = AQ_CLEAR;//��

    EPwm2Regs.ETSEL.bit.INTEN = 0; // Disable interrupt


    EPwm3Regs.TBPRD = TimeBase;                   // Set timer period
    EPwm3Regs.TBPHS.bit.TBPHS = 0x0000;           // Phase is 0
    EPwm3Regs.TBCTR = 0x0000;                     // Clear counter

    EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP; // Count UPDOWN
    EPwm3Regs.TBCTL.bit.PHSEN = TB_DISABLE;        // Disable phase loading
    EPwm3Regs.TBCTL.bit.HSPCLKDIV = 1;       // Clock ratio to SYSCLKOUT
    EPwm3Regs.TBCTL.bit.CLKDIV = 1;

    EPwm3Regs.CMPA.bit.CMPA = TimeBase;
    EPwm3Regs.CMPB.bit.CMPB = TimeBase;//CMPB
    EPwm3Regs.AQCTLA.bit.CAU = AQ_SET;            // Set PWM3A on Zero
    EPwm3Regs.AQCTLA.bit.PRD = AQ_CLEAR;

    EPwm3Regs.AQCTLB.bit.CBU = AQ_SET;            // Set PWM3B on Zero
    EPwm3Regs.AQCTLB.bit.ZRO = AQ_CLEAR;

    EPwm3Regs.ETSEL.bit.INTEN = 0;


    EPwm4Regs.TBPRD = TimeBase;                   // Set timer period
    EPwm4Regs.TBPHS.bit.TBPHS = 0x0000;           // Phase is 0
    EPwm4Regs.TBCTR = 0x0000;                     // Clear counter

    EPwm4Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP; // Count UPDOWN
    EPwm4Regs.TBCTL.bit.PHSEN = TB_DISABLE;        // Disable phase loading
    EPwm4Regs.TBCTL.bit.HSPCLKDIV = 1;       // Clock ratio to SYSCLKOUT
    EPwm4Regs.TBCTL.bit.CLKDIV = 1;

    EPwm4Regs.CMPA.bit.CMPA = TimeBase;
    EPwm4Regs.CMPB.bit.CMPB = TimeBase;//CMPB

    EPwm4Regs.AQCTLA.bit.CAU = AQ_SET;            // Set PWM4A on Zero
    EPwm4Regs.AQCTLA.bit.PRD = AQ_CLEAR;//��

    EPwm4Regs.AQCTLB.bit.CBU = AQ_SET;            // Set PWM4B on Zero
    EPwm4Regs.AQCTLB.bit.ZRO = AQ_CLEAR;//��

    EPwm4Regs.ETSEL.bit.INTEN = 0; // Disable interrupt
}
